// Função para carregar o mapa de localização
function displayMap() {
    const mapOptions = {
        center: { lat: -33.860664, lng: 151.208138 },
        zoom: 14
    };
    const mapDiv = document.getElementById('map');
    const map = new google.maps.Map(mapDiv, mapOptions);
    return map;
}

document.getElementById('mapa').addEventListener('click', function() {
    // Coordenadas de exemplo (substitua pelas suas coordenadas)
    const latitude = -19.85925;
    const longitude = -43.91892;

    // Constrói a URL do Google Maps com as coordenadas
    const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;

    // Abre a URL em uma nova aba
    window.open(googleMapsUrl, '_blank');
});

// Funções para navegação do carrossel
let currentIndex = 0;

function prevSlide() {
    if (currentIndex > 0) {
        currentIndex--;
        updateCarousel();
    }
}

function nextSlide() {
    const totalSlides = document.querySelectorAll('.carousel-item').length;
    if (currentIndex < totalSlides - 1) {
        currentIndex++;
        updateCarousel();
    }
}

function updateCarousel() {
    const carouselInner = document.querySelector('.carousel-inner');
    const slideWidth = document.querySelector('.carousel-item').offsetWidth;
    carouselInner.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
}

// Eventos de clique para os botões de planos de mensalidades
document.getElementById('planoMensal100').addEventListener('click', function() {
    window.location.href = 'paginas/pagamentos.html';  // URL do plano mensal de R$100,00
});

document.getElementById('planoMensal220').addEventListener('click', function() {
     window.location.href = 'paginas/pagamentos.html'; // URL do plano mensal de R$220,00
});

document.getElementById('comprar100').addEventListener('click', function() {
     window.location.href = 'paginas/pagamentos.html'; // URL do botão "Comprar" para o plano de R$100,00
});

document.getElementById('comprar220').addEventListener('click', function() {
     window.location.href = 'paginas/pagamentos.html'; // URL do botão "Comprar" para o plano de R$220,00
});

// Eventos de clique para os botões de cima "Solicitar Carona" e "Login/Cadastro"
document.getElementById('solicitarCarona').addEventListener('click', function() {
    window.location.href = 'paginas/caronas.html'; // URL para solicitar carona
});

document.getElementById('Login/Cadastro').addEventListener('click', function() {
 window.location.href = 'paginas/login.html'; // URL para login/cadastro
});

const botoesImagem = document.querySelectorAll('.imagem-button');

// Adiciona o evento de redimensionamento ao passar o mouse para cada botão
botoesImagem.forEach(botao => {
    botao.addEventListener('mouseover', () => {
        botao.style.transform = 'scale(1.1)';
    });

    botao.addEventListener('mouseleave', () => {
        botao.style.transform = 'scale(1)';
    });
});

// Eventos de clique para os imagens de dentro do carrosel--------------------------
document.addEventListener("DOMContentLoaded", function() {
    // Seleciona as imagens clicáveis
    var imagem1 = document.getElementById("imagem1");
    var imagem2 = document.getElementById("imagem2");

    // Adiciona um evento de clique para cada imagem
    imagem1.addEventListener("click", function() {
        window.location.href = "pagina1.html"; // Substitua "pagina1.html" pelo URL desejado para a primeira imagem
    });

    imagem2.addEventListener("click", function() {
        window.location.href = "pagina2.html"; // Substitua "pagina2.html" pelo URL desejado para a segunda imagem
    });
});

// Evento de carregamento da página para inicializar o mapa
document.addEventListener('DOMContentLoaded', function() {
    const loader = new Promise(resolve => {
        window.initMap = resolve;
    });

    loader.then(() => {
        console.log('Maps JS API loaded');
        const map = displayMap();
    });
});
