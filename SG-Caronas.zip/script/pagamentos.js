function showTab(tabName) {
  var tabcontents = document.getElementsByClassName('tabcontent');
  for (var i = 0; i < tabcontents.length; i++) {
    tabcontents[i].style.display = 'none';
  }
  document.getElementById(tabName).style.display = 'block';
}

document.addEventListener('DOMContentLoaded', function() {
  showTab('cartao');
});

function copiarLink() {
  var inputElement = document.createElement('input');
  inputElement.value = 'https://www.sistemas.pucminas.br/sgaaluno4/SilverStream/Pages/pgAln_LoginSSL.html';
  document.body.appendChild(inputElement);
  inputElement.select();
  document.execCommand('copy');
  document.body.removeChild(inputElement);
  var button = document.querySelector('.copiar button');
  button.textContent = 'QR Code Copiado!';
}

function validarCampos() {
  var currentTab = document.querySelector('.tabcontent[style*="display: block"]');
  var inputs = currentTab.querySelectorAll('input');
  var allFilled = true;
  var emptyFields = [];

  inputs.forEach(function(input) {
    if (!input.value.trim()) {
      allFilled = false;
      var label = document.querySelector(`label[for="${input.id}"]`);
      if (label) {
        emptyFields.push(label.textContent);
      } else {
        emptyFields.push(input.placeholder || input.name);
      }
    }
  });

  if (allFilled) {
    saveData(currentTab.id);
    alert('Compra finalizada');
  } else {
    alert('Por favor, preencha os seguintes campos: ' + emptyFields.join(', '));
  }
}

function saveData(tabId) {
  if (tabId === 'cartao') {
    const cardData = {
      NumCartao: document.getElementById('NumCartao').value,
      Vencimento: document.getElementById('Vencimento').value,
      CVV: document.getElementById('CVV').value,
      Titular: document.getElementById('Titular').value,
      CPF: document.getElementById('CPF').value,
      Celular: document.getElementById('Celular').value,
      Parcelas: document.querySelector('input[name="opcao"]:checked').value
    };
    localStorage.setItem('cardData', JSON.stringify(cardData));
  } else if (tabId === 'boleto') {
    const boletoData = {
      Nome: document.getElementById('nome').value,
      CPF: document.getElementById('cpf').value,
      Endereco: document.getElementById('endereco').value,
      Valor: document.getElementById('valor').value
    };
    localStorage.setItem('boletoData', JSON.stringify(boletoData));
  }
}

document.querySelector('.finalizar-compra').addEventListener('click', validarCampos);
