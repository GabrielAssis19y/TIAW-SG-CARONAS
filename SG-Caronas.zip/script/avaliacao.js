//estrelas js
var stars = document.querySelectorAll('.star-icon');

document.addEventListener('click', function(e) {
  var classStar = e.target.classList;
  if (!classStar.contains('ativo')) {
    stars.forEach(function(star) {
      star.classList.remove('ativo');
    });
    classStar.add('ativo');
    console.log(e.target.getAttribute('data-avaliacao'));
  }
});

function Comentar() {
  const comentario = document.getElementById('comentario').value;
  if (comentario.trim()) {
      console.log('Comentário enviado:', comentario);
      document.getElementById('comentario').value = '';
  } else {
      alert('Por favor, escreva um comentário antes de enviar.');
  }
};

function Denunciar() {
  const denuncia = document.getElementById('denuncia').value;
  if (denuncia.trim()) {
      console.log('Denúncia enviada:', denuncia);
      document.getElementById('denuncia').value = '';
  } else {
      alert('Por favor, escreva algo antes de enviar.');
  }
};


const pessoas = [
  {
    nome: "Júlia",
    idade: "18",
    matricula: "2024001",
    curso: "Análise e Desenvolvimento de Sistemas",
    carroModelo: "Gol",
    carroAno: "2022",
    carroMarca: "Volkswagen",
    carroCor: "Vermelho",
    carroPlaca: "JHN-1234"
  },
  {
    nome: "Roberto",
    idade: "20",
    matricula: "2024002",
    curso: "Sistemas de Informação",
    carroModelo: "Uno",
    carroAno: "2019",
    carroMarca: "Fiat",
    carroCor: "Preto",
    carroPlaca: "HIU-1212"
  },
  {
    nome: "Carlos",
    idade: "21",
    matricula: "2024003",
    curso: "Direito",
    carroModelo: "Bravo",
    carroAno: "2013",
    carroMarca: "Fiat",
    carroCor: "Prata",
    carroPlaca: "UOQ-5523"
  },
  {
    nome: "Maria",
    idade: "19",
    matricula: "2024004",
    curso: "Jornalismo",
    carroModelo: "Focus",
    carroAno: "2016",
    carroMarca: "Ford",
    carroCor: "Branco",
    carroPlaca: "TIP-3443"
  }
];

let divInfoAberta = null;

function MostrarInfo(event) {
  let divClicada = event.currentTarget;

  let idDiv = divClicada.id;
  let index = parseInt(idDiv.replace("corrida", "")) - 1;

  let pessoaSelecionada = pessoas[index];

  let divInfo = document.createElement('div');
  divInfo.className = 'popup';

  let imagensContainer = document.createElement('div');
  imagensContainer.className = 'imagens-container';
  imagensContainer.style.display = 'flex';
  imagensContainer.style.alignItems = 'center';
  imagensContainer.style.marginBottom = '10px';

  var imagemDivClicada = divClicada.querySelector('img');
  var imagem1 = imagemDivClicada.cloneNode(true);
  imagem1.style.width = '80px';
  imagensContainer.appendChild(imagem1);

  var imagemEstrelas = document.createElement('img');
  imagemEstrelas.src = '/imagens/estrelas2.png';
  imagemEstrelas.style.width = '200px';
  imagensContainer.appendChild(imagemEstrelas);

  divInfo.appendChild(imagensContainer);



  let svgIconChat = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svgIconChat.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  svgIconChat.setAttribute('width', '25');
  svgIconChat.setAttribute('height', '25');
  svgIconChat.setAttribute('fill', 'currentColor');
  svgIconChat.setAttribute('class', 'bi bi-chat-dots');
  svgIconChat.setAttribute('viewBox', '0 0 16 16');
  svgIconChat.style.position = 'absolute';
  svgIconChat.style.bottom = '10px';
  svgIconChat.style.left = '10px';
  svgIconChat.style.cursor = 'pointer';

  let pathChat1 = document.createElementNS("http://www.w3.org/2000/svg", "path");
  pathChat1.setAttribute('d', 'M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2');
  svgIconChat.appendChild(pathChat1);

  let pathChat2 = document.createElementNS("http://www.w3.org/2000/svg", "path");
  pathChat2.setAttribute('d', 'm2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9 9 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.4 10.4 0 0 1-.524 2.318l-.003.011a11 11 0 0 1-.244.637c-.079.186.074.394.273.362a22 22 0 0 0 .693-.125m.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6-3.004 6-7 6a8 8 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a11 11 0 0 0 .398-2');
  svgIconChat.appendChild(pathChat2);

  svgIconChat.addEventListener('click', function() {
    window.location.href = "paginaChat.html";
  });

  divInfo.appendChild(svgIconChat);


  let svgIcon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svgIcon.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  svgIcon.setAttribute('width', '25');
  svgIcon.setAttribute('height', '25');
  svgIcon.setAttribute('fill', 'currentColor');
  svgIcon.setAttribute('class', 'bi bi-x');
  svgIcon.setAttribute('viewBox', '0 0 16 16');
  svgIcon.style.position = 'absolute';
  svgIcon.style.top = '0';
  svgIcon.style.right = '0';
  svgIcon.style.cursor = 'pointer';

  let path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute('d', 'M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708');

  svgIcon.appendChild(path);

  divInfo.appendChild(svgIcon);


  svgIcon.addEventListener('click', function() {
    divInfoAberta.remove();
  })

  let titulo = document.createElement('h3');
  titulo.textContent = pessoaSelecionada.nome;
  divInfo.appendChild(titulo);

  let info = document.createElement('p');
  info.innerHTML = `<strong>Idade:</strong> ${pessoaSelecionada.idade}<br>
                    <strong>Matrícula:</strong> ${pessoaSelecionada.matricula}<br>
                    <strong>Curso:</strong> ${pessoaSelecionada.curso}<br>
                    <strong>Carro:</strong> ${pessoaSelecionada.carroMarca} ${pessoaSelecionada.carroModelo} ${pessoaSelecionada.carroAno}<br>
                    <strong>Placa:</strong> ${pessoaSelecionada.carroPlaca}<br>`;
  divInfo.appendChild(info);

  if (divInfoAberta) {
    divInfoAberta.remove();
  }

  document.body.appendChild(divInfo);

  divInfoAberta = divInfo;
}